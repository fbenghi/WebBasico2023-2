1. Executar `npm install` no terminal para instalar as dependência indicadas em `package.json`
    > Cria a pasta node_modules e faz download das dependências

1. Excutar o comando `npm start` no terminal para iniciar o servidor
    > Este comando é definido no arquivo `package.json` e é equivalente a executar node 
    > `Escutando a porta 3000` deve ter aparecido no terminal (deixar rodando)
    > No navegador: `localhost:3000/cards` exibe uma lista JSON de cards

1. Copie o site para a pasta `express`
    > O site passou a estar acessível no endereço `localhost:3000`



