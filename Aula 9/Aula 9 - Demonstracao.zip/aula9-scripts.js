const btn = document.getElementById('btn');

btn.onclick = function(){
  window.alert('O botão funcionou!');
}