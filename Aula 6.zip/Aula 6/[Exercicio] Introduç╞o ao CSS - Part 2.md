# **Desenvolvimento Web Básico**
## Aula 06 - Introdução ao CSS
Prof. Felipe Marx Benghi 
    
## Atividade Prática
1. Reproduza a seguinte página web

![Alt text](_img/ex-webpage.png)